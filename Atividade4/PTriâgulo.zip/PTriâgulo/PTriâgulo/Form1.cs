﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriâgulo
{
    public partial class Form1 : Form
    {
        double LA, LB, LC;


        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out LC))
            {
                MessageBox.Show("informe um núemro");
                txtLadoC.Focus();
            }
        }

        private void txtLadoA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }

        }

        private void txtLadoB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtLadoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out LB))
            {
                MessageBox.Show("informe um núemro");
                txtLadoB.Focus();
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtLadoA.Text, out LA) && double.TryParse(txtLadoB.Text, out LB) && double.TryParse(txtLadoC.Text, out LC))

                if (LA < (LB + LC) && LA > Math.Abs(LB - LC) && LB < (LA + LC) && LB > Math.Abs(LA - LC) && LC < (LA + LB) && LC > Math.Abs(LA - LB))
                {

                    if (LA == LB && LB == LC)
                        MessageBox.Show("Triangulo Equilatero");
                    else if (LA == LB || LA == LC || LB == LC)
                        MessageBox.Show("Triangulo Isosceles");
                    else if
                    (LA != LB && LB != LC && LA != LC)
                        MessageBox.Show("Triangulo Escaleno");
                }
                else
                    MessageBox.Show("Os valores não formam um triângulo");
                
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out LA))
            {
                MessageBox.Show("Informe um numero");
                txtLadoA.Focus();

            }

            if (txtLadoA.Text == "")
            {
                MessageBox.Show("numero invalido");
            }
        }
    }
}
