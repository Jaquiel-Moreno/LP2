﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form

    {
        //<===================>variáveis Globais<===============================>

        string EstdCivl;
        double SalrBruto, SalrFaml, SalrLiqd, DescINSS,DescIRPF, Fun;

        private void Form1_Load(object sender, EventArgs e)
        {
            cbxNumflh.Text = "0";
        }


        //<========================>butto Calculos==============================>
        private void btnValDados_Click(object sender, EventArgs e)
        {
          if(SalrBruto <= 800.47)
            {
                txtAliquotaINSS.Text = "7,65%";
                DescINSS = 0.0765 * SalrBruto;
                txtDinss.Text = DescINSS.ToString("f2");
            }
          else
                 if (SalrBruto <= 1050)
            {
                txtAliquotaINSS.Text = "8,65%";
                DescINSS = 0.0865 * SalrBruto;
                txtDinss.Text = DescINSS.ToString("f2");
            }
          else
                 if (SalrBruto <= 1400.77)
            {
                txtAliquotaINSS.Text = "9,00%";
                DescINSS = 0.0900 * SalrBruto;
                txtDinss.Text = DescINSS.ToString("f2");
            }
          else
            if (SalrBruto <= 2801.56)
            {
                txtAliquotaINSS.Text = "11,00%";
                DescINSS = 0.110 * SalrBruto;
                txtDinss.Text = DescINSS.ToString("f2");
            }
          else            
            {
                txtAliquotaINSS.Text = "0";
                DescINSS =308.17;
                txtDinss.Text = DescINSS.ToString("f2");
            }
            if (SalrBruto <= 1257.12)
            {
                txtAliquotaIRPF.Text = "0";
                DescIRPF = 0 * SalrBruto;
                txtDescIRPF.Text = DescIRPF.ToString("f2");
            }
            else
                 if (SalrBruto <= 2512.08)
            {
                txtAliquotaIRPF.Text = "15,00%";
                DescIRPF = 0.15 * SalrBruto;
                txtDescIRPF.Text = DescIRPF.ToString("f2");
            }
            else
            {
                txtAliquotaIRPF.Text = "27,00%";
                DescIRPF = 0.28 * SalrBruto;
                txtDescIRPF.Text = DescIRPF.ToString("f2");
            }
            if (SalrBruto <= 435.52)
            {
                SalrFaml = 22.33 * Convert.ToDouble(cbxNumflh.Text);
                txtSalFamilia.Text = SalrFaml.ToString("f2");
            }
            else
                if (SalrBruto <= 654.74)
            {
                SalrFaml = 15.74 * Convert.ToDouble(cbxNumflh.Text);
                txtSalFamilia.Text = SalrFaml.ToString("f2");
            }
            else
                if(SalrBruto >= 654.61)
            {
                SalrFaml = 0 * Convert.ToDouble(cbxNumflh.Text);
                txtSalFamilia.Text = SalrFaml.ToString("f2");
            }
            
            SalrLiqd = SalrBruto - DescINSS - DescIRPF + SalrFaml;
            txtSalLiquido.Text = SalrLiqd.ToString();



                lblDescr.Text = " O funcionário (a) " + txtNomeFuncionario.Text + " é " + EstdCivl  + "\n tem " + cbxNumflh.Text + " filho(a)" +" tem um salário de R$ " + txtSalarioBruto.Text   + "\n Tem uma aliquota de INSS de " + txtAliquotaINSS.Text + " \n  segue  os descontos e salário liquído abaixo." ;
        }

        //<=================>check do estado civil<==============================>
        private void cbxCasado_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxCasado.Checked)
            {
                EstdCivl = "Casado";

            }
            else
              //  if(!cbxCasado.Checked)
            { 
                EstdCivl = "Solteiro";
            }
        }


        //<=================>validação do Salário Bruto<===========================>
        private void txtSalarioBruto_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtSalarioBruto.Text, out SalrBruto))
            {
                MessageBox.Show("Salário Inválido");
                txtSalarioBruto.Focus();
            }
            else  
                if(SalrBruto <= 0)
            {
                MessageBox.Show("Salário deve ser maior que zero");
            }

        }

        //<========================>butto Sair<===================================>
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }




        //<============>validação do Nome do funcionário<=========================>
        private void txtNomeFuncionario_Validated(object sender, EventArgs e)
        {

            if (Double.TryParse(txtNomeFuncionario.Text, out Fun))
            {
                MessageBox.Show("nome inválido");
                //txtNomeFuncionario.Focus();
            }
            else
             if (txtNomeFuncionario.Text == "" || txtNomeFuncionario.Text == " ")
            {
                MessageBox.Show("Nome Inválido");
                txtNomeFuncionario.Focus();
            }

        }

      
        public Form1()
        {
            InitializeComponent();
        }
        //<====================>Buttoo Limpar os txts<============================>
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            cbxNumflh.Text = "0";
            txtNomeFuncionario.Clear();
            txtSalarioBruto.Clear();
            txtAliquotaINSS.Clear();
            txtAliquotaIRPF.Clear();
            txtDinss.Clear();
            txtDescIRPF.Clear();
            txtAliquotaIRPF.Clear();
            txtSalFamilia.Clear();
            



        }
    }
}
