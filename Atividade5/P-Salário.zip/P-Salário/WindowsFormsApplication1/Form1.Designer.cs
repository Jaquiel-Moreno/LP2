﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnf = new System.Windows.Forms.Label();
            this.lblSALBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.txtNomeFuncionario = new System.Windows.Forms.TextBox();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.btnValDados = new System.Windows.Forms.Button();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblIAliqRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.txtAliquotaINSS = new System.Windows.Forms.TextBox();
            this.txtAliquotaIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.gpbx = new System.Windows.Forms.GroupBox();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFemino = new System.Windows.Forms.RadioButton();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.cbxCasado = new System.Windows.Forms.CheckBox();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIRPF = new System.Windows.Forms.Label();
            this.txtDinss = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.lblDescr = new System.Windows.Forms.Label();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.cbxNumflh = new System.Windows.Forms.ComboBox();
            this.gpbx.SuspendLayout();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblnf
            // 
            this.lblnf.AutoSize = true;
            this.lblnf.Location = new System.Drawing.Point(12, 38);
            this.lblnf.Name = "lblnf";
            this.lblnf.Size = new System.Drawing.Size(184, 24);
            this.lblnf.TabIndex = 0;
            this.lblnf.Text = "Nome Funcionário";
            // 
            // lblSALBruto
            // 
            this.lblSALBruto.AutoSize = true;
            this.lblSALBruto.Location = new System.Drawing.Point(12, 87);
            this.lblSALBruto.Name = "lblSALBruto";
            this.lblSALBruto.Size = new System.Drawing.Size(129, 24);
            this.lblSALBruto.TabIndex = 1;
            this.lblSALBruto.Text = "Salário Bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(12, 135);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(178, 24);
            this.lblNumFilhos.TabIndex = 2;
            this.lblNumFilhos.Text = "Número de Filhos";
            // 
            // txtNomeFuncionario
            // 
            this.txtNomeFuncionario.Location = new System.Drawing.Point(202, 38);
            this.txtNomeFuncionario.Name = "txtNomeFuncionario";
            this.txtNomeFuncionario.Size = new System.Drawing.Size(359, 29);
            this.txtNomeFuncionario.TabIndex = 1;
            this.txtNomeFuncionario.Validated += new System.EventHandler(this.txtNomeFuncionario_Validated);
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(195, 84);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(123, 29);
            this.txtSalarioBruto.TabIndex = 2;
            this.txtSalarioBruto.Validated += new System.EventHandler(this.txtSalarioBruto_Validated);
            // 
            // btnValDados
            // 
            this.btnValDados.Location = new System.Drawing.Point(161, 220);
            this.btnValDados.Name = "btnValDados";
            this.btnValDados.Size = new System.Drawing.Size(261, 50);
            this.btnValDados.TabIndex = 5;
            this.btnValDados.Text = "validar Dados";
            this.btnValDados.UseVisualStyleBackColor = true;
            this.btnValDados.Click += new System.EventHandler(this.btnValDados_Click);
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Location = new System.Drawing.Point(6, 443);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(138, 24);
            this.lblAliqINSS.TabIndex = 7;
            this.lblAliqINSS.Text = "Aliquota INSS";
            // 
            // lblIAliqRPF
            // 
            this.lblIAliqRPF.AutoSize = true;
            this.lblIAliqRPF.Location = new System.Drawing.Point(6, 483);
            this.lblIAliqRPF.Name = "lblIAliqRPF";
            this.lblIAliqRPF.Size = new System.Drawing.Size(137, 24);
            this.lblIAliqRPF.TabIndex = 8;
            this.lblIAliqRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(6, 518);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(147, 24);
            this.lblSalFamilia.TabIndex = 9;
            this.lblSalFamilia.Text = "Salário Familia";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(6, 561);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(149, 24);
            this.lblSalLiquido.TabIndex = 10;
            this.lblSalLiquido.Text = "Salário Liquído";
            // 
            // txtAliquotaINSS
            // 
            this.txtAliquotaINSS.Enabled = false;
            this.txtAliquotaINSS.Location = new System.Drawing.Point(161, 443);
            this.txtAliquotaINSS.Name = "txtAliquotaINSS";
            this.txtAliquotaINSS.Size = new System.Drawing.Size(219, 29);
            this.txtAliquotaINSS.TabIndex = 11;
            // 
            // txtAliquotaIRPF
            // 
            this.txtAliquotaIRPF.Enabled = false;
            this.txtAliquotaIRPF.Location = new System.Drawing.Point(161, 480);
            this.txtAliquotaIRPF.Name = "txtAliquotaIRPF";
            this.txtAliquotaIRPF.Size = new System.Drawing.Size(219, 29);
            this.txtAliquotaIRPF.TabIndex = 12;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(161, 515);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(219, 29);
            this.txtSalFamilia.TabIndex = 13;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(161, 556);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(219, 29);
            this.txtSalLiquido.TabIndex = 14;
            // 
            // gpbx
            // 
            this.gpbx.Controls.Add(this.rbtnMasculino);
            this.gpbx.Controls.Add(this.rbtnFemino);
            this.gpbx.Location = new System.Drawing.Point(660, 26);
            this.gpbx.Name = "gpbx";
            this.gpbx.Size = new System.Drawing.Size(245, 179);
            this.gpbx.TabIndex = 4;
            this.gpbx.TabStop = false;
            this.gpbx.Text = "sexo";
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Location = new System.Drawing.Point(31, 63);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(123, 28);
            this.rbtnMasculino.TabIndex = 1;
            this.rbtnMasculino.Text = "Masculino";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // rbtnFemino
            // 
            this.rbtnFemino.AutoSize = true;
            this.rbtnFemino.Checked = true;
            this.rbtnFemino.Location = new System.Drawing.Point(31, 29);
            this.rbtnFemino.Name = "rbtnFemino";
            this.rbtnFemino.Size = new System.Drawing.Size(116, 28);
            this.rbtnFemino.TabIndex = 0;
            this.rbtnFemino.TabStop = true;
            this.rbtnFemino.Text = "Feminino";
            this.rbtnFemino.UseVisualStyleBackColor = true;
            // 
            // pnlCasado
            // 
            this.pnlCasado.Controls.Add(this.cbxCasado);
            this.pnlCasado.Location = new System.Drawing.Point(664, 283);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(245, 111);
            this.pnlCasado.TabIndex = 18;
            // 
            // cbxCasado
            // 
            this.cbxCasado.AutoSize = true;
            this.cbxCasado.Location = new System.Drawing.Point(31, 41);
            this.cbxCasado.Name = "cbxCasado";
            this.cbxCasado.Size = new System.Drawing.Size(99, 28);
            this.cbxCasado.TabIndex = 0;
            this.cbxCasado.Text = "Casado";
            this.cbxCasado.UseVisualStyleBackColor = true;
            this.cbxCasado.CheckedChanged += new System.EventHandler(this.cbxCasado_CheckedChanged);
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Location = new System.Drawing.Point(503, 410);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(150, 24);
            this.lblDescontoINSS.TabIndex = 19;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRPF
            // 
            this.lblDescontoIRPF.AutoSize = true;
            this.lblDescontoIRPF.Location = new System.Drawing.Point(505, 452);
            this.lblDescontoIRPF.Name = "lblDescontoIRPF";
            this.lblDescontoIRPF.Size = new System.Drawing.Size(149, 24);
            this.lblDescontoIRPF.TabIndex = 20;
            this.lblDescontoIRPF.Text = "Desconto IRPF";
            // 
            // txtDinss
            // 
            this.txtDinss.Enabled = false;
            this.txtDinss.Location = new System.Drawing.Point(664, 405);
            this.txtDinss.Name = "txtDinss";
            this.txtDinss.Size = new System.Drawing.Size(249, 29);
            this.txtDinss.TabIndex = 21;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(660, 450);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(249, 29);
            this.txtDescIRPF.TabIndex = 22;
            // 
            // lblDescr
            // 
            this.lblDescr.AutoSize = true;
            this.lblDescr.Location = new System.Drawing.Point(35, 307);
            this.lblDescr.Name = "lblDescr";
            this.lblDescr.Size = new System.Drawing.Size(103, 24);
            this.lblDescr.TabIndex = 23;
            this.lblDescr.Text = "Descrição";
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(471, 233);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 37);
            this.btnSair.TabIndex = 24;
            this.btnSair.Text = "Sair";
            this.btnSair.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(603, 233);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(80, 37);
            this.btnLimpar.TabIndex = 25;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // cbxNumflh
            // 
            this.cbxNumflh.FormattingEnabled = true;
            this.cbxNumflh.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbxNumflh.Location = new System.Drawing.Point(196, 135);
            this.cbxNumflh.Name = "cbxNumflh";
            this.cbxNumflh.Size = new System.Drawing.Size(121, 32);
            this.cbxNumflh.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(952, 651);
            this.Controls.Add(this.cbxNumflh);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.lblDescr);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDinss);
            this.Controls.Add(this.lblDescontoIRPF);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.gpbx);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliquotaIRPF);
            this.Controls.Add(this.txtAliquotaINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblIAliqRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.btnValDados);
            this.Controls.Add(this.txtSalarioBruto);
            this.Controls.Add(this.txtNomeFuncionario);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSALBruto);
            this.Controls.Add(this.lblnf);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "P-Salário";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gpbx.ResumeLayout(false);
            this.gpbx.PerformLayout();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnf;
        private System.Windows.Forms.Label lblSALBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.TextBox txtNomeFuncionario;
        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.Button btnValDados;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblIAliqRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.TextBox txtAliquotaINSS;
        private System.Windows.Forms.TextBox txtAliquotaIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.GroupBox gpbx;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFemino;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.CheckBox cbxCasado;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIRPF;
        private System.Windows.Forms.TextBox txtDinss;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.Label lblDescr;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ComboBox cbxNumflh;
    }
}

