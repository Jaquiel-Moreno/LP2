﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double Num1, Num2, Resultado;

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(textBox2.Text,out Num2))
            {
                MessageBox.Show("Informe o segundo Numero");
                textBox2.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Focus();
            textBox2.Clear();
            textBox2.Focus();
            textBox3.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {

             Close(); 
    
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox1.Text!="" & textBox2.Text != "") 
            {
                Num1 = Convert.ToDouble(textBox1.Text);
                Num2 = Convert.ToDouble(textBox2.Text);
                Resultado = Num1+Num2;
                textBox3.Text = Resultado.ToString();

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" & textBox2.Text != "")
            {
                Num1 = Convert.ToDouble(textBox1.Text);
                Num2 = Convert.ToDouble(textBox2.Text);
                Resultado = Num1 - Num2;
                textBox3.Text = Resultado.ToString();

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" & textBox2.Text != "")
            {
                Num1 = Convert.ToDouble(textBox1.Text);
                Num2 = Convert.ToDouble(textBox2.Text);
                Resultado = Num1 * Num2;
                textBox3.Text = Resultado.ToString();

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" & textBox2.Text != "0")
            {
                Num1 = Convert.ToDouble(textBox1.Text);
                Num2 = Convert.ToDouble(textBox2.Text);
                Resultado = Num1 / Num2;
                textBox3.Text = Resultado.ToString("f2");

            }
            else
            { 
                MessageBox.Show("Informe um Numero maior que zero 0");
                textBox2.Focus();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar)||char.IsPunctuation(e.KeyChar)|| char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsWhiteSpace(e.KeyChar))
            {
             e.Handled = true;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            
            if(!Double.TryParse(textBox1.Text, out Num1))
            {
                MessageBox.Show("Informe primeiro numero");
                textBox1.Focus();

            }
        }
    }
}
