﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PProva1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            String X;
            int[,] N = new int [4,10];

            char [] Gab = new char[5]{'A','B','C','D','E'};

            for(int i=0;i<4;i++)
            {
                for(int J=0;J>10)
                {
                    if(J==)
                }
                if (i > 0 && i < 4)
                {
                    
                }

                X = Interaction.InputBox("Informe as Resposta", "Entrada de Dados");
            }




            

            


        }
    }
}
